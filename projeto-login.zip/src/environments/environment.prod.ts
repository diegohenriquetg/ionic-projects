export const environment = {
  production: true,
  googleMapsAPIKey: 'YOUR_GOOGLE_MAPS_API_KEY',
  firebaseAPIKey: 'AIzaSyD7kdV7prW5nEjdLe3QumP7NzBPgRSnoA0'
};
